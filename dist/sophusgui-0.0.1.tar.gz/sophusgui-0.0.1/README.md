# SophusGUI

A GUI library very fast and simplified. It has good quality and very
delicate attributes.