from tkinter import *
from tkinter import ttk

def create_gui_app():
    window=Tk()
    window.configure(width=500, height=900)
    window.configure(bg="lightgray")
    window.mainloop()